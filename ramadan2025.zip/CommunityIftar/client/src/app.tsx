import React from 'react';
import { Route, Switch } from 'wouter';
import { TooltipProvider } from '@radix-ui/react-tooltip';

function App() {
  return (
    <TooltipProvider>
      <div className="min-h-screen bg-background">
        <Switch>
          <Route path="/" component={() => <div>Home</div>} />
          {/* Add other routes here */}
        </Switch>
      </div>
    </TooltipProvider>
  );
}

export default App;